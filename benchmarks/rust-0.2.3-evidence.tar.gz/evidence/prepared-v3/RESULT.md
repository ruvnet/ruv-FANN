# Prepared v3 measured result

Source `fe1ec2032c0851e6f6bf698ca01335f7122155d8` (integrated source file hashes verified identical) passes all 60 scalar bit checks and cross-revision fixture/output signatures over 12 balanced rounds, totaling 45,360 reported blocks of at least 2 ms. The focused suite passes 46 tests; forcing the canonical cache guard to true makes both float-width topology tests fail.

Primary public 0.2.2 comparison: equal-case geometric mean latency ratio 0.9001 (95% interval 0.8880–0.9168); dense 0.8667, controls 0.9526. Tiny-case aggregate 0.9769 has an interval including parity. On 784→128→64→10, speedups are 2.491×/2.498× for f32 Linear/Sigmoid and 1.702×/1.748× for f64.

Acceptance requires review: f32 Linear 10→4→1 is 6.31% slower [ratio 1.0468–1.0784]; f32 Linear 63→17→5 is 5.60% slower [1.0332–1.0787]; f32 Sigmoid 63→17→5 is 6.90% slower [1.0123–1.1340]; f64 Sigmoid 33→17→5 is 7.89% slower [1.0398–1.1491]. These intervals exclude parity, while none lies entirely above a 5% slowdown. All cases and comparison against the intermediate revision remain in REPORT.md and analysis.json.

This shared-host run used CPU11 with no system/governor changes. Host load ranged 4.52–14.91; SMT sibling27 busy time had median 1.40% and maximum 30.34%. Paired round intervals and order balancing reduce drift but do not remove scheduler, SMT, or frequency uncertainty. These are local measurements, not a universal speed or state-of-the-art claim.

The checksummed crates.io 0.2.2 archive and its entire library source/manifest/lock comparison identify the public primary baseline. Full provenance is in ../public-0.2.2 and build_metadata.json. Failed v1 and v2 candidates and their evidence are preserved in ../prepared and ../prepared-v2.
