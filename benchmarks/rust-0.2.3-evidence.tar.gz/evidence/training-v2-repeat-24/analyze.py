from pathlib import Path
from collections import defaultdict
import csv,hashlib,json,random,statistics
ROOT=Path(__file__).resolve().parent

def quantile(values,fraction):
    values=sorted(values);position=(len(values)-1)*fraction;index=int(position);next_index=min(index+1,len(values)-1)
    return values[index]+(values[next_index]-values[index])*(position-index)

def main():
    grouped=defaultdict(dict);signatures=set();raw_values=defaultdict(list);block_ms=[]
    for path in sorted(ROOT.glob('run-??-*.csv')):
        _,round_tag,variant=path.stem.split('-');rows=list(csv.DictReader(path.open()))
        assert len(rows)==21
        values=[float(row['ns_per_pattern']) for row in rows]
        grouped[int(round_tag)][variant]=statistics.median(values)
        raw_values[variant].extend(values)
        for row in rows:
            assert row['iterations']=='16' and row['rows']=='16'
            signatures.add((row['weight_checksum'],row['weight_bits_hash']))
            block_ms.append(float(row['ns_per_pattern'])*256/1e6)
    assert sorted(grouped)==list(range(24))
    assert len(signatures)==1
    pairs=[grouped[index] for index in range(24)]
    ratios=[pair['baseline']/pair['candidate'] for pair in pairs]
    rng=random.Random(20261111)
    bootstrap=[statistics.median(rng.choices(ratios,k=24)) for _ in range(20000)]
    ci=[quantile(bootstrap,0.025),quantile(bootstrap,0.975)]
    ratio=statistics.median(ratios);threshold=1/1.05
    report={'baseline_revision':'251e23cd63d182ad805f9e2c24c1468754db92bb','candidate_revision':'f35c5b93e4177ec4a22694e2b05e4f2f210bf39e','published_baseline_identity_receipt':'../public-0.2.2/all-src-git-blob-comparison.json','case':{'precision':'f32','shape':[128,128,64,16],'topology':'reordered'},'outer_pairs':24,'raw_blocks_per_variant':len(raw_values['baseline']),'raw_blocks_total':len(block_ms),'raw_block_duration_ms':{'minimum':min(block_ms),'median':statistics.median(block_ms),'maximum':max(block_ms)},'raw_blocks_at_least_20ms':all(value>=20 for value in block_ms),'median_paired_speed_ratio':ratio,'speed_ratio_two_sided_95pct_bootstrap_ci':ci,'candidate_latency_change_percent':(1/ratio-1)*100,'candidate_latency_change_two_sided_95pct_ci_percent':[(1/ci[1]-1)*100,(1/ci[0]-1)*100],'baseline_median_ns_per_pattern':statistics.median(pair['baseline'] for pair in pairs),'candidate_median_ns_per_pattern':statistics.median(pair['candidate'] for pair in pairs),'noninferiority':{'allowed_latency_increase_percent':5,'required_speed_ratio_lower_bound':threshold,'observed_ci_lower_bound':ci[0],'established':ci[0]>=threshold,'criterion_predeclared':True},'weight_checksum':next(iter(signatures))[0],'weight_bits_hash':next(iter(signatures))[1],'all_weight_signatures_match':True,'paired_round_medians_ns':pairs,'paired_speed_ratios':ratios,'bootstrap':{'replicates':20000,'seed':20261111,'unit':'outer-round paired medians of21raw blocks','statistic':'medianbaseline/candidatethroughputratio','interval':'two-sided95%percentile'},'samples_deleted':0,'limitations':['One selected physical core on one Ryzen9950X host; background load and SMT activity remain possible.','Synthetic reordered model and training throughput only; no quality or SOTA comparison.','Timing excludes fixture creation, cloning and destruction, but includes allocations within Network::train.','Focused harness has longer blocks than the previous full matrix and independently rebuilt identical source for both variants.'],'analyzer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    manifest={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(ROOT.iterdir()) if path.is_file() and path.name!='evidence-sha256.json'}
    (ROOT/'evidence-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({key:value for key,value in report.items() if key not in ('paired_round_medians_ns','paired_speed_ratios')},indent=2))

if __name__=='__main__':main()
