from pathlib import Path
from collections import defaultdict
import csv,hashlib,json,random,statistics
ROOT=Path(__file__).resolve().parent

def quantile(values,fraction):
    ordered=sorted(values)
    position=(len(ordered)-1)*fraction
    low=int(position)
    high=min(low+1,len(ordered)-1)
    return ordered[low]+(ordered[high]-ordered[low])*(position-low)

def main():
    observations=defaultdict(dict)
    signatures=defaultdict(set)
    counts=defaultdict(int)
    for raw in sorted(ROOT.glob('run-??-*.csv')):
        _,round_tag,variant=raw.stem.split('-')
        round_index=int(round_tag)
        per_case=defaultdict(list)
        for row in csv.DictReader(raw.open()):
            key=(row['precision'],row['shape'],row['topology'])
            per_case[key].append(float(row['ns_per_pattern']))
            signatures[key].add((row['weight_checksum'],row['weight_bits_hash']))
            counts[key]+=1
        assert len(per_case)==12,(raw,len(per_case))
        for key,values in per_case.items():
            assert len(values)==21,(raw,key,len(values))
            observations[key].setdefault(round_index,{})[variant]=statistics.median(values)
    summary={'baseline_sha':'251e23cd63d182ad805f9e2c24c1468754db92bb','candidate_sha':'5f9a8dcec618abd19a58be24646fd6ca98eff1d3','analysis':'Median baseline/candidate ratio of12paired outer rounds. Each outer value is median of21raw timing blocks.95%percentile bootstrap intervals resample outer-round pairs, seed20261111,20000replicates; captures observed timing noise, not workload or machine diversity.','results':[],'all_exact_weight_signatures_match':True,'raw_rows':sum(counts.values()),'limitations':['Synthetic deterministic fixtures and onephysicalcore on oneAMD Ryzen9950X host. NoSOTA or model quality comparison.','Fixed fixture order within each binary; balancedAB/BA outer rounds mitigate but cannot exclude host/thermal drift.','NoCPU governor changes; system background activity and siblingSMT scheduling remain possible.','Point timings exclude fixture creation/network clones/destruction; allocation inside publicNetwork::train remains included.','External harness uses oneidentical independently resolved dependency lock and minimalfeature config across both variants.']}
    rng=random.Random(20261111)
    for key,rounds in sorted(observations.items()):
        assert sorted(rounds)==list(range(12)),(key,sorted(rounds))
        assert len(signatures[key])==1,(key,signatures[key])
        pairs=[rounds[index] for index in range(12)]
        ratios=[pair['baseline']/pair['candidate'] for pair in pairs]
        boot=[statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(20000)]
        low,high=quantile(boot,0.025),quantile(boot,0.975)
        speedup=statistics.median(ratios)
        checksum,weight_hash=next(iter(signatures[key]))
        result={'precision':key[0],'shape':key[1],'topology':key[2],'outer_rounds':len(pairs),'raw_measurements_per_variant':counts[key]//2,'baseline_median_ns_per_pattern':statistics.median(pair['baseline'] for pair in pairs),'candidate_median_ns_per_pattern':statistics.median(pair['candidate'] for pair in pairs),'median_paired_speedup':speedup,'speedup_95pct_bootstrap_ci':[low,high],'candidate_latency_change_percent':(1/speedup-1)*100,'candidate_latency_change_95pct_ci_percent':[(1/high-1)*100,(1/low-1)*100],'weight_checksum':checksum,'weight_bits_hash':weight_hash,'paired_round_medians_ns':pairs,'paired_speedups':ratios}
        summary['results'].append(result)
    summary['analysis_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    fields=['precision','shape','topology','baseline_median_ns_per_pattern','candidate_median_ns_per_pattern','median_paired_speedup','speedup_95pct_bootstrap_ci','candidate_latency_change_percent']
    with (ROOT/'summary.csv').open('w') as output:
        writer=csv.DictWriter(output,fieldnames=fields)
        writer.writeheader()
        for result in summary['results']:writer.writerow({key:result[key] for key in fields})
    print('All6048raw observations have identical weight signatures within eachfixture across variants.')
    for result in summary['results']:
        print(result['precision'],result['shape'],result['topology'],f"{result['median_paired_speedup']:.3f}x",[round(value,3) for value in result['speedup_95pct_bootstrap_ci']],f"latency {result['candidate_latency_change_percent']:+.2f}%")

if __name__=='__main__':main()
