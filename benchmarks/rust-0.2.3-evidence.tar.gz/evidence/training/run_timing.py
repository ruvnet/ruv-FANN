from pathlib import Path
import csv,hashlib,json,os,subprocess,time

ROOT=Path(__file__).resolve().parent
ROUNDS=12
CPU=4

def cpu_stats():
    return {line.split()[0]:list(map(int,line.split()[1:])) for line in Path('/proc/stat').read_text().splitlines() if line.startswith(('cpu4 ','cpu20 '))}

def main():
    metadata=json.loads((ROOT/'metadata.json').read_text())
    metadata['timing']={'outer_rounds':ROUNDS,'inner_measurements_per_case':21,'inner_warmup_blocks_per_case':7,'order':'baseline/candidate on even rounds; candidate/baseline on odd rounds','cpu':CPU,'method':'Each process measures12fixtures in identical order. A timing block trains one cloned initial network for fixed repeated epochs; cloning/destruction excluded. Ratios pair each outer round using median of21within-process timings.','source_tree_status_before':{}}
    for name,path in [('baseline','/home/ruvultra/projects/ruv-FANN-training-baseline'),('candidate','/home/ruvultra/projects/ruv-FANN-rust-training')]:
        status=subprocess.check_output(['git','-C',path,'status','--porcelain'],text=True)
        assert not status,(name,status)
        metadata['timing']['source_tree_status_before'][name]=status
        binary=ROOT/name/'fann-dense-training-benchmark'
        assert hashlib.sha256(binary.read_bytes()).hexdigest()==metadata['builds'][name]['binary_sha256']
    metadata['timing']['started_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    metadata['timing']['cpu_stats_before']=cpu_stats()
    governor=Path(f'/sys/devices/system/cpu/cpu{CPU}/cpufreq/scaling_governor')
    metadata['timing']['cpu_governor']=governor.read_text().strip() if governor.exists() else 'unavailable'
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    events=[]
    for round_index in range(ROUNDS):
        order=('baseline','candidate') if round_index%2==0 else ('candidate','baseline')
        for name in order:
            stem=f'run-{round_index:02d}-{name}'
            command=['taskset','-c',str(CPU),str(ROOT/name/'fann-dense-training-benchmark')]
            start=time.monotonic()
            with (ROOT/(stem+'.csv')).open('w') as output,(ROOT/(stem+'.stderr')).open('w') as errors:
                result=subprocess.run(command,stdout=output,stderr=errors)
            assert result.returncode==0,(name,result.returncode)
            with (ROOT/(stem+'.csv')).open() as output:
                rows=list(csv.DictReader(output))
            assert len(rows)==252,(stem,len(rows))
            event={'round':round_index,'variant':name,'command':command,'elapsed_seconds':time.monotonic()-start,'raw_sha256':hashlib.sha256((ROOT/(stem+'.csv')).read_bytes()).hexdigest()}
            events.append(event)
            print(json.dumps(event),flush=True)
        (ROOT/'timing-events.json').write_text(json.dumps(events,indent=2)+'\n')
    metadata['timing']['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    metadata['timing']['cpu_stats_after']=cpu_stats()
    metadata['timing']['raw_rows']=ROUNDS*2*252
    metadata['timing']['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')

if __name__=='__main__':
    main()
