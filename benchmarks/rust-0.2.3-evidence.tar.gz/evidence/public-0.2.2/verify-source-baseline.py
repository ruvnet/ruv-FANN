from pathlib import Path
import hashlib,json,subprocess,tomllib
ROOT=Path(__file__).resolve().parent
PUBLIC=ROOT/'ruv-fann-0.2.2'
REPO='/home/ruvultra/projects/ruv-FANN-training-baseline'
SHA='251e23cd63d182ad805f9e2c24c1468754db92bb'
def git(*args):return subprocess.check_output(['git','-C',REPO,*args])
def digest(data):return hashlib.sha256(data).hexdigest()
def main():
    files={}
    for entry in git('ls-tree','-r','-z',SHA,'--','src').split(b'\0'):
        if not entry:continue
        info,name=entry.split(b'\t');mode,kind,oid=info.decode().split();assert kind=='blob'
        files[name.decode()]=oid
    public_files={str(path.relative_to(PUBLIC)) for path in (PUBLIC/'src').rglob('*') if path.is_file()}
    rows=[]
    for name,oid in sorted(files.items()):
        baseline=git('cat-file','blob',oid);published=(PUBLIC/name).read_bytes() if name in public_files else None
        rows.append({'path':name,'git_blob':oid,'baseline_sha256':digest(baseline),'published_sha256':digest(published) if published is not None else None,'identical':baseline==published})
    baseline_manifest=git('show',SHA+':Cargo.toml');published_manifest=(PUBLIC/'Cargo.toml.orig').read_bytes()
    base=tomllib.loads(baseline_manifest.decode());public=tomllib.loads(published_manifest.decode())
    baseline_lock=git('show',SHA+':Cargo.lock');published_lock=(PUBLIC/'Cargo.lock').read_bytes()
    report={'baseline_revision':SHA,'baseline_tree':git('rev-parse',SHA+'^{tree}').decode().strip(),'provenance':'crates.io0.2.2downloadarchive;archiveSHA256matchespreservedsparse-registryindex0.2.2checksum;seeecomparison-receipt.json','published_archive_sha256':digest((ROOT/'ruv-fann-0.2.2.crate').read_bytes()),'file_map_identical':set(files)==public_files,'baseline_src_count':len(files),'published_src_count':len(public_files),'all_src_bytes_identical':all(row['identical'] for row in rows),'published_only_src_paths':sorted(public_files-set(files)),'cargo_original_manifest_bytes_identical':baseline_manifest==published_manifest,'cargo_original_manifest_baseline_sha256':digest(baseline_manifest),'cargo_original_manifest_published_sha256':digest(published_manifest),'normalized_dependencies_identical':{name:base.get(name)==public.get(name) for name in ['dependencies','dev-dependencies','build-dependencies','features','target']},'cargo_lock_bytes_identical':baseline_lock==published_lock,'cargo_lock_baseline_sha256':digest(baseline_lock),'cargo_lock_published_sha256':digest(published_lock),'files':rows,'verifier_sha256':digest(Path(__file__).read_bytes())}
    (ROOT/'all-src-git-blob-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({key:value for key,value in report.items() if key!='files'},indent=2))
if __name__=='__main__':main()
