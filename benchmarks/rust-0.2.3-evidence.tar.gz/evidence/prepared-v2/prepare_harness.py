from pathlib import Path
import hashlib, json, subprocess
root=Path('/home/ruvultra/projects/fann-rust-performance-evidence/prepared-v2')
source=Path('/home/ruvultra/projects/ruv-FANN-prepared-v2/examples/prepared_matrix.rs')
(root/'prepared_matrix.rs').write_bytes(source.read_bytes())
variants={
 'baseline':('/home/ruvultra/projects/ruv-FANN-prepared-baseline','251e23cd63d182ad805f9e2c24c1468754db92bb'),
 'intermediate':('/home/ruvultra/projects/ruv-FANN-prepared-intermediate','8bf15ebb947719b14d9c926ea40342ba8f15336a'),
 'candidate':('/home/ruvultra/projects/ruv-FANN-prepared-v2','53cee636b1697db59860e640e3dc135411ce2e43'),
}
metadata={}
for name,(repo,sha) in variants.items():
 directory=root/name; directory.mkdir(exist_ok=True)
 manifest='''[package]
name = "prepared-matrix-harness"
version = "0.0.0"
edition = "2021"
[workspace]
[dependencies]
ruv-fann = { path = "%s", default-features = false, features = ["std"] }
num-traits = "0.2"
[[bin]]
name = "prepared-matrix"
path = "../prepared_matrix.rs"
[profile.release]
opt-level = 3
codegen-units = 16
lto = false
''' % repo
 (directory/'Cargo.toml').write_text(manifest)
 actual=subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
 assert actual==sha
 metadata[name]={'repo':repo,'sha':sha,'tree':subprocess.check_output(['git','-C',repo,'rev-parse',sha+'^{tree}'],text=True).strip(),'manifest_sha256':hashlib.sha256(manifest.encode()).hexdigest()}
metadata['benchmark_source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
metadata['rustflags']='-C opt-level=3 -C codegen-units=16 -C lto=off'
metadata['features']=['std']
metadata['profile']='release opt-level=3, codegen-units=16, lto=off, panic=unwind'
(root/'source_metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
