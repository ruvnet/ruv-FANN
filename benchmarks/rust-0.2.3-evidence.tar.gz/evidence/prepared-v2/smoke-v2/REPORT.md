# Prepared single-inference benchmark

Per-run case medians of configured >=2ms blocks; paired revision ratios across configured order-balanced rounds; geometric mean ratio and seeded 2000-resample percentile 95% interval over rounds. Values below 1 are faster. Intervals describe this host and run protocol, not other machines.

All 60 fixture/output bit signatures match across three revisions and all rounds; 7560 raw timing blocks.

| Case | Baseline ns | Intermediate ns | Candidate ns | Candidate / baseline (95% CI) | Candidate / intermediate (95% CI) |
|---|---:|---:|---:|---:|---:|
| f32_linear_dense_100x50x25x10 | 1786.98 | 1770.63 | 1483.08 | 0.8300 [0.8149, 0.8491] | 0.8360 [0.8209, 0.8526] |
| f32_linear_dense_10x1 | 13.27 | 12.71 | 12.88 | 0.9700 [0.9620, 0.9799] | 1.0104 [1.0014, 1.0167] |
| f32_linear_dense_10x4x1 | 36.56 | 37.94 | 36.41 | 1.0117 [0.9836, 1.0592] | 0.9777 [0.9549, 1.0184] |
| f32_linear_dense_33x17x5 | 219.99 | 239.22 | 226.59 | 1.0095 [0.9767, 1.0363] | 0.9500 [0.9258, 0.9775] |
| f32_linear_dense_5x7x3 | 56.69 | 54.26 | 53.63 | 0.9468 [0.9421, 0.9533] | 0.9891 [0.9813, 1.0012] |
| f32_linear_dense_63x17x5 | 329.64 | 371.67 | 360.32 | 1.0902 [1.0799, 1.0997] | 0.9759 [0.9555, 0.9984] |
| f32_linear_dense_64x17x5 | 371.07 | 354.52 | 319.16 | 0.8663 [0.8329, 0.9047] | 0.9009 [0.8829, 0.9226] |
| f32_linear_dense_65x17x5 | 370.40 | 378.87 | 315.09 | 0.8622 [0.8467, 0.8783] | 0.8460 [0.8310, 0.8627] |
| f32_linear_dense_784x128x64x10 | 39133.00 | 38715.50 | 17787.03 | 0.4568 [0.4529, 0.4614] | 0.4617 [0.4555, 0.4690] |
| f32_linear_mixed_33x17x5 | 220.99 | 218.75 | 218.08 | 1.0388 [0.9797, 1.1533] | 1.0480 [0.9927, 1.1633] |
| f32_linear_mixed_65x17x5 | 365.14 | 390.86 | 364.14 | 0.9993 [0.9901, 1.0080] | 0.9313 [0.9235, 0.9410] |
| f32_linear_reordered_33x17x5 | 243.70 | 264.30 | 240.30 | 0.9840 [0.9711, 0.9947] | 0.9108 [0.9055, 0.9167] |
| f32_linear_reordered_65x17x5 | 409.20 | 451.04 | 408.77 | 0.9919 [0.9775, 1.0038] | 0.9046 [0.8970, 0.9117] |
| f32_linear_sparse_33x17x5 | 196.17 | 209.02 | 190.18 | 0.9742 [0.9609, 0.9840] | 0.9138 [0.9014, 0.9312] |
| f32_linear_sparse_65x17x5 | 287.81 | 328.55 | 287.65 | 0.9910 [0.9767, 1.0014] | 0.8752 [0.8722, 0.8775] |
| f32_sigmoid_dense_100x50x25x10 | 2711.91 | 2786.67 | 1996.38 | 0.7327 [0.7260, 0.7395] | 0.7187 [0.7142, 0.7229] |
| f32_sigmoid_dense_10x1 | 19.26 | 18.65 | 18.66 | 0.9584 [0.9427, 0.9721] | 1.0026 [0.9954, 1.0105] |
| f32_sigmoid_dense_10x4x1 | 54.36 | 52.95 | 52.53 | 0.9742 [0.9674, 0.9822] | 0.9953 [0.9895, 1.0009] |
| f32_sigmoid_dense_33x17x5 | 339.90 | 333.48 | 338.43 | 0.9936 [0.9850, 1.0029] | 1.0181 [1.0039, 1.0382] |
| f32_sigmoid_dense_5x7x3 | 86.19 | 84.24 | 83.67 | 0.9716 [0.9673, 0.9756] | 0.9934 [0.9856, 1.0004] |
| f32_sigmoid_dense_63x17x5 | 519.47 | 577.41 | 549.43 | 1.0545 [1.0377, 1.0688] | 0.9521 [0.9459, 0.9589] |
| f32_sigmoid_dense_64x17x5 | 559.80 | 556.50 | 387.08 | 0.6922 [0.6757, 0.7087] | 0.6987 [0.6937, 0.7053] |
| f32_sigmoid_dense_65x17x5 | 549.05 | 583.54 | 403.13 | 0.7385 [0.7315, 0.7455] | 0.6922 [0.6885, 0.6969] |
| f32_sigmoid_dense_784x128x64x10 | 42647.67 | 42888.50 | 18761.98 | 0.4387 [0.4357, 0.4414] | 0.4379 [0.4361, 0.4399] |
| f32_sigmoid_mixed_33x17x5 | 332.89 | 345.13 | 336.65 | 1.0049 [0.9931, 1.0143] | 0.9710 [0.9548, 0.9859] |
| f32_sigmoid_mixed_65x17x5 | 523.03 | 553.28 | 527.10 | 1.0006 [0.9851, 1.0162] | 0.9360 [0.9008, 0.9586] |
| f32_sigmoid_reordered_33x17x5 | 427.03 | 442.66 | 428.71 | 1.0065 [0.9965, 1.0165] | 0.9504 [0.9029, 0.9821] |
| f32_sigmoid_reordered_65x17x5 | 648.45 | 682.74 | 651.35 | 1.0038 [0.9984, 1.0089] | 0.9408 [0.9141, 0.9592] |
| f32_sigmoid_sparse_33x17x5 | 334.83 | 352.08 | 334.96 | 0.9974 [0.9831, 1.0123] | 0.9353 [0.9083, 0.9551] |
| f32_sigmoid_sparse_65x17x5 | 497.77 | 516.58 | 498.19 | 0.9884 [0.9569, 1.0088] | 0.9413 [0.9036, 0.9662] |
| f64_linear_dense_100x50x25x10 | 1752.59 | 1733.84 | 1499.46 | 0.8559 [0.8414, 0.8728] | 0.8571 [0.8187, 0.8860] |
| f64_linear_dense_10x1 | 13.71 | 12.73 | 13.00 | 0.9518 [0.9476, 0.9561] | 0.9973 [0.9487, 1.0251] |
| f64_linear_dense_10x4x1 | 36.56 | 36.61 | 34.40 | 0.9448 [0.9403, 0.9484] | 0.9406 [0.9342, 0.9477] |
| f64_linear_dense_33x17x5 | 220.73 | 248.16 | 222.99 | 1.0144 [1.0011, 1.0275] | 0.9051 [0.8852, 0.9283] |
| f64_linear_dense_5x7x3 | 55.46 | 54.68 | 54.33 | 0.9541 [0.9149, 0.9857] | 0.9875 [0.9763, 0.9986] |
| f64_linear_dense_63x17x5 | 338.31 | 366.10 | 346.10 | 1.0239 [1.0044, 1.0464] | 0.9560 [0.9408, 0.9720] |
| f64_linear_dense_64x17x5 | 344.50 | 337.15 | 333.52 | 0.9643 [0.9386, 0.9910] | 0.9863 [0.9607, 1.0125] |
| f64_linear_dense_65x17x5 | 354.69 | 351.46 | 337.82 | 0.9514 [0.9305, 0.9693] | 0.9638 [0.9459, 0.9848] |
| f64_linear_dense_784x128x64x10 | 39330.40 | 39247.66 | 17206.15 | 0.4531 [0.4360, 0.4832] | 0.4532 [0.4366, 0.4823] |
| f64_linear_mixed_33x17x5 | 266.72 | 223.98 | 247.22 | 0.9225 [0.9001, 0.9439] | 1.0939 [1.0781, 1.1131] |
| f64_linear_mixed_65x17x5 | 442.50 | 387.08 | 410.59 | 0.9324 [0.9215, 0.9460] | 1.0616 [1.0325, 1.0861] |
| f64_linear_reordered_33x17x5 | 341.87 | 247.45 | 346.36 | 1.0111 [1.0035, 1.0167] | 1.3904 [1.3752, 1.4049] |
| f64_linear_reordered_65x17x5 | 562.12 | 412.59 | 572.54 | 1.0157 [1.0072, 1.0247] | 1.3824 [1.3609, 1.4094] |
| f64_linear_sparse_33x17x5 | 254.24 | 199.49 | 258.66 | 1.0192 [0.9993, 1.0354] | 1.2956 [1.2768, 1.3090] |
| f64_linear_sparse_65x17x5 | 404.20 | 291.78 | 412.04 | 1.0199 [1.0155, 1.0243] | 1.4006 [1.3837, 1.4176] |
| f64_sigmoid_dense_100x50x25x10 | 2894.42 | 2876.18 | 2168.02 | 0.7491 [0.7425, 0.7553] | 0.7531 [0.7462, 0.7613] |
| f64_sigmoid_dense_10x1 | 21.37 | 19.93 | 20.36 | 0.9406 [0.9130, 0.9640] | 1.0211 [1.0101, 1.0347] |
| f64_sigmoid_dense_10x4x1 | 67.97 | 58.69 | 60.19 | 0.8689 [0.8418, 0.8865] | 1.0194 [1.0072, 1.0291] |
| f64_sigmoid_dense_33x17x5 | 375.39 | 384.47 | 390.78 | 1.0285 [0.9974, 1.0557] | 1.0183 [1.0041, 1.0344] |
| f64_sigmoid_dense_5x7x3 | 103.43 | 99.30 | 98.44 | 0.9661 [0.9328, 1.0000] | 1.0058 [0.9643, 1.0592] |
| f64_sigmoid_dense_63x17x5 | 579.49 | 557.44 | 560.47 | 0.9413 [0.9039, 0.9704] | 1.0041 [0.9942, 1.0137] |
| f64_sigmoid_dense_64x17x5 | 576.06 | 549.73 | 434.73 | 0.7597 [0.7536, 0.7665] | 0.7969 [0.7868, 0.8089] |
| f64_sigmoid_dense_65x17x5 | 593.94 | 591.70 | 437.62 | 0.7412 [0.7317, 0.7546] | 0.7435 [0.7345, 0.7554] |
| f64_sigmoid_dense_784x128x64x10 | 42807.77 | 42948.86 | 18689.54 | 0.4355 [0.4318, 0.4399] | 0.4356 [0.4300, 0.4413] |
| f64_sigmoid_mixed_33x17x5 | 390.53 | 367.25 | 383.08 | 0.9813 [0.9687, 0.9934] | 1.0426 [1.0346, 1.0527] |
| f64_sigmoid_mixed_65x17x5 | 609.37 | 555.24 | 603.60 | 0.9887 [0.9726, 1.0039] | 1.0860 [1.0798, 1.0907] |
| f64_sigmoid_reordered_33x17x5 | 495.97 | 453.69 | 495.23 | 1.0006 [0.9973, 1.0030] | 1.0930 [1.0873, 1.0975] |
| f64_sigmoid_reordered_65x17x5 | 742.39 | 678.08 | 742.91 | 1.0025 [0.9993, 1.0062] | 1.0943 [1.0882, 1.0999] |
| f64_sigmoid_sparse_33x17x5 | 381.51 | 348.36 | 383.56 | 0.9984 [0.9854, 1.0077] | 1.1007 [1.0990, 1.1024] |
| f64_sigmoid_sparse_65x17x5 | 573.70 | 528.45 | 573.06 | 0.9999 [0.9972, 1.0031] | 1.0846 [1.0805, 1.0891] |

## Group geometric means

| Comparison | Group | Cases | Ratio | 95% CI |
|---|---|---:|---:|---:|
| intermediate/baseline | all | 60 | 0.9767 | [0.9660, 0.9875] |
| intermediate/baseline | dense | 36 | 0.9951 | [0.9847, 1.0055] |
| intermediate/baseline | controls | 24 | 0.9497 | [0.9381, 0.9644] |
| intermediate/baseline | tiny | 12 | 0.9594 | [0.9475, 0.9710] |
| intermediate/baseline | large | 12 | 1.0131 | [1.0020, 1.0234] |
| candidate/baseline | all | 60 | 0.8997 | [0.8959, 0.9034] |
| candidate/baseline | dense | 36 | 0.8416 | [0.8375, 0.8460] |
| candidate/baseline | controls | 24 | 0.9944 | [0.9892, 0.9995] |
| candidate/baseline | tiny | 12 | 0.9544 | [0.9496, 0.9592] |
| candidate/baseline | large | 12 | 0.7090 | [0.7045, 0.7134] |
| candidate/intermediate | all | 60 | 0.9211 | [0.9132, 0.9298] |
| candidate/intermediate | dense | 36 | 0.8457 | [0.8399, 0.8522] |
| candidate/intermediate | controls | 24 | 1.0470 | [1.0319, 1.0610] |
| candidate/intermediate | tiny | 12 | 0.9948 | [0.9866, 1.0050] |
| candidate/intermediate | large | 12 | 0.6998 | [0.6950, 0.7051] |

## Regressions requiring review

- candidate/baseline, f32_linear_dense_10x4x1: 1.17% slower; 95% CI [0.9836, 1.0592]. Interval includes parity.
- candidate/baseline, f32_linear_dense_33x17x5: 0.95% slower; 95% CI [0.9767, 1.0363]. Interval includes parity.
- candidate/baseline, f32_linear_dense_63x17x5: 9.02% slower; 95% CI [1.0799, 1.0997]. Interval excludes parity.
- candidate/baseline, f32_linear_mixed_33x17x5: 3.88% slower; 95% CI [0.9797, 1.1533]. Interval includes parity.
- candidate/baseline, f32_sigmoid_dense_63x17x5: 5.45% slower; 95% CI [1.0377, 1.0688]. Interval excludes parity.
- candidate/baseline, f32_sigmoid_mixed_33x17x5: 0.49% slower; 95% CI [0.9931, 1.0143]. Interval includes parity.
- candidate/baseline, f32_sigmoid_mixed_65x17x5: 0.06% slower; 95% CI [0.9851, 1.0162]. Interval includes parity.
- candidate/baseline, f32_sigmoid_reordered_33x17x5: 0.65% slower; 95% CI [0.9965, 1.0165]. Interval includes parity.
- candidate/baseline, f32_sigmoid_reordered_65x17x5: 0.38% slower; 95% CI [0.9984, 1.0089]. Interval includes parity.
- candidate/baseline, f64_linear_dense_33x17x5: 1.44% slower; 95% CI [1.0011, 1.0275]. Interval excludes parity.
- candidate/baseline, f64_linear_dense_63x17x5: 2.39% slower; 95% CI [1.0044, 1.0464]. Interval excludes parity.
- candidate/baseline, f64_linear_reordered_33x17x5: 1.11% slower; 95% CI [1.0035, 1.0167]. Interval excludes parity.
- candidate/baseline, f64_linear_reordered_65x17x5: 1.57% slower; 95% CI [1.0072, 1.0247]. Interval excludes parity.
- candidate/baseline, f64_linear_sparse_33x17x5: 1.92% slower; 95% CI [0.9993, 1.0354]. Interval includes parity.
- candidate/baseline, f64_linear_sparse_65x17x5: 1.99% slower; 95% CI [1.0155, 1.0243]. Interval excludes parity.
- candidate/baseline, f64_sigmoid_dense_33x17x5: 2.85% slower; 95% CI [0.9974, 1.0557]. Interval includes parity.
- candidate/baseline, f64_sigmoid_reordered_33x17x5: 0.06% slower; 95% CI [0.9973, 1.0030]. Interval includes parity.
- candidate/baseline, f64_sigmoid_reordered_65x17x5: 0.25% slower; 95% CI [0.9993, 1.0062]. Interval includes parity.
- candidate/intermediate, f32_linear_dense_10x1: 1.04% slower; 95% CI [1.0014, 1.0167]. Interval excludes parity.
- candidate/intermediate, f32_linear_mixed_33x17x5: 4.80% slower; 95% CI [0.9927, 1.1633]. Interval includes parity.
- candidate/intermediate, f32_sigmoid_dense_10x1: 0.26% slower; 95% CI [0.9954, 1.0105]. Interval includes parity.
- candidate/intermediate, f32_sigmoid_dense_33x17x5: 1.81% slower; 95% CI [1.0039, 1.0382]. Interval excludes parity.
- candidate/intermediate, f64_linear_mixed_33x17x5: 9.39% slower; 95% CI [1.0781, 1.1131]. Interval excludes parity.
- candidate/intermediate, f64_linear_mixed_65x17x5: 6.16% slower; 95% CI [1.0325, 1.0861]. Interval excludes parity.
- candidate/intermediate, f64_linear_reordered_33x17x5: 39.04% slower; 95% CI [1.3752, 1.4049]. Interval excludes parity.
- candidate/intermediate, f64_linear_reordered_65x17x5: 38.24% slower; 95% CI [1.3609, 1.4094]. Interval excludes parity.
- candidate/intermediate, f64_linear_sparse_33x17x5: 29.56% slower; 95% CI [1.2768, 1.3090]. Interval excludes parity.
- candidate/intermediate, f64_linear_sparse_65x17x5: 40.06% slower; 95% CI [1.3837, 1.4176]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_dense_10x1: 2.11% slower; 95% CI [1.0101, 1.0347]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_dense_10x4x1: 1.94% slower; 95% CI [1.0072, 1.0291]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_dense_33x17x5: 1.83% slower; 95% CI [1.0041, 1.0344]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_dense_5x7x3: 0.58% slower; 95% CI [0.9643, 1.0592]. Interval includes parity.
- candidate/intermediate, f64_sigmoid_dense_63x17x5: 0.41% slower; 95% CI [0.9942, 1.0137]. Interval includes parity.
- candidate/intermediate, f64_sigmoid_mixed_33x17x5: 4.26% slower; 95% CI [1.0346, 1.0527]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_mixed_65x17x5: 8.60% slower; 95% CI [1.0798, 1.0907]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_reordered_33x17x5: 9.30% slower; 95% CI [1.0873, 1.0975]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_reordered_65x17x5: 9.43% slower; 95% CI [1.0882, 1.0999]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_sparse_33x17x5: 10.07% slower; 95% CI [1.0990, 1.1024]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_sparse_65x17x5: 8.46% slower; 95% CI [1.0805, 1.0891]. Interval excludes parity.
