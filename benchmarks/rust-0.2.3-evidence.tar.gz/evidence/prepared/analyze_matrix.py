from collections import defaultdict
from pathlib import Path
import hashlib, json, math, random, statistics
root=Path(__file__).resolve().parent
runs=json.loads((root/'runs.json').read_text())
values={}; signatures={}; fixture_signatures={}; block_count=0
for run in runs:
 assert run['returncode']==0
 path=root/run['file']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==run['output_sha256']
 by_case=defaultdict(list)
 for line in path.read_text().splitlines():
  row=json.loads(line); key=(run['round'],run['variant'],row['case'])
  if row['kind']=='correctness':
   signatures.setdefault(row['case'],set()).add(row['output_signature'])
   fixture_signatures.setdefault(row['case'],set()).add(row['fixture_signature'])
  else:
   assert row['elapsed_ns']>=2_000_000
   by_case[row['case']].append(row['ns_per_call']); block_count+=1
 for case,blocks in by_case.items():
  assert len(blocks)==21
  values[(run['round'],run['variant'],case)]=statistics.median(blocks)
assert len(runs)==36 and len(signatures)==36
assert all(len(x)==1 for x in signatures.values())
assert all(len(x)==1 for x in fixture_signatures.values())
def geomean(items): return math.exp(statistics.mean(map(math.log,items)))
def interval(ratios):
 rng=random.Random(0x74a98)
 samples=sorted(geomean(rng.choices(ratios,k=len(ratios))) for _ in range(20000))
 return [samples[499],samples[19499]]
report={'method':'Per-run case medians of 21 >=2ms blocks; paired revision ratios across 12 order-balanced rounds; geometric mean ratio and seeded 20000-resample percentile 95% interval over rounds. Values below 1 are faster. Intervals describe this host and run protocol, not other machines.','rounds':12,'cases':36,'raw_blocks':block_count,'all_bit_signatures_match':True,'comparisons':{}}
for numerator,denominator in [('intermediate','baseline'),('candidate','baseline'),('candidate','intermediate')]:
 name=f'{numerator}/{denominator}'
 comparison={}
 for case in sorted(signatures):
  ratios=[values[(r,numerator,case)]/values[(r,denominator,case)] for r in range(12)]
  comparison[case]={'ratio':geomean(ratios),'ci95':interval(ratios),'round_ratios':ratios,'denominator_ns':statistics.median(values[(r,denominator,case)] for r in range(12)),'numerator_ns':statistics.median(values[(r,numerator,case)] for r in range(12))}
 report['comparisons'][name]=comparison
report['aggregate']={}
for name,comparison in report['comparisons'].items():
 report['aggregate'][name]={}
 for group,predicate in [('all',lambda case:True),('dense',lambda case:'_dense_' in case),('controls',lambda case:'_dense_' not in case),('tiny',lambda case:case.endswith(('_10x1','_10x4x1','_5x7x3'))),('large',lambda case:case.endswith(('_33x17x5','_100x50x25x10','_784x128x64x10')) and '_dense_' in case)]:
  cases=[case for case in comparison if predicate(case)]
  ratios=[geomean(comparison[case]['round_ratios'][r] for case in cases) for r in range(12)]
  report['aggregate'][name][group]={'cases':len(cases),'ratio':geomean(ratios),'ci95':interval(ratios)}
(root/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# Prepared single-inference benchmark','',report['method'],'',f'All {len(signatures)} fixture/output bit signatures match across three revisions and twelve rounds; {block_count} raw timing blocks.','', '| Case | Baseline ns | Intermediate ns | Candidate ns | Candidate / baseline (95% CI) | Candidate / intermediate (95% CI) |','|---|---:|---:|---:|---:|---:|']
for case in sorted(signatures):
 a=report['comparisons']['candidate/baseline'][case]; b=report['comparisons']['candidate/intermediate'][case]
 lines.append(f"| {case} | {a['denominator_ns']:.2f} | {b['denominator_ns']:.2f} | {a['numerator_ns']:.2f} | {a['ratio']:.4f} [{a['ci95'][0]:.4f}, {a['ci95'][1]:.4f}] | {b['ratio']:.4f} [{b['ci95'][0]:.4f}, {b['ci95'][1]:.4f}] |")
lines+=['','## Group geometric means','','| Comparison | Group | Cases | Ratio | 95% CI |','|---|---|---:|---:|---:|']
for name,groups in report['aggregate'].items():
 for group,row in groups.items(): lines.append(f"| {name} | {group} | {row['cases']} | {row['ratio']:.4f} | [{row['ci95'][0]:.4f}, {row['ci95'][1]:.4f}] |")
lines+=['','## Regressions requiring review','']
for name in ['candidate/baseline','candidate/intermediate']:
 for case,row in report['comparisons'][name].items():
  if row['ratio']>1:
   lines.append(f"- {name}, {case}: {(row['ratio']-1)*100:.2f}% slower; 95% CI [{row['ci95'][0]:.4f}, {row['ci95'][1]:.4f}]." + (' Interval excludes parity.' if row['ci95'][0]>1 else ' Interval includes parity.'))
(root/'REPORT.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(report['aggregate'],indent=2))
print('\n'.join(lines[lines.index('## Regressions requiring review'):]))
