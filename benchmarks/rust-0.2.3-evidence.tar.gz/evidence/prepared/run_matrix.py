from pathlib import Path
import datetime, hashlib, itertools, json, os, subprocess, time
root=Path(__file__).resolve().parent
variants=['baseline','intermediate','candidate']
orders=list(itertools.permutations(variants))*2
raw=root/'raw'; raw.mkdir(exist_ok=True)
def host():
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadavg':Path('/proc/loadavg').read_text().strip(),'selected_cpu_stat':next(x for x in Path('/proc/stat').read_text().splitlines() if x.startswith('cpu11 ')), 'sibling_cpu_stat':next(x for x in Path('/proc/stat').read_text().splitlines() if x.startswith('cpu27 '))}
 for filename in ['scaling_cur_freq','scaling_governor']:
  path=Path('/sys/devices/system/cpu/cpu11/cpufreq')/filename
  if path.exists(): result[filename]=path.read_text().strip()
 return result
manifest=[]
for round_index,order in enumerate(orders):
 for position,variant in enumerate(order):
  destination=raw/f'round-{round_index:02d}-{position}-{variant}.jsonl'
  assert not destination.exists(),f'preserve previous results: {destination}'
  binary=root/variant/'target/release/prepared-matrix'
  command=['taskset','-c','11',str(binary)]
  entry={'round':round_index,'position':position,'variant':variant,'command':command,'before':host(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
  start=time.monotonic()
  with destination.open('w') as output, destination.with_suffix('.stderr').open('w') as error:
   result=subprocess.run(command,stdout=output,stderr=error)
  entry.update({'after':host(),'wall_seconds':time.monotonic()-start,'returncode':result.returncode,'output_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'file':str(destination.relative_to(root))})
  manifest.append(entry)
  (root/'runs.json').write_text(json.dumps(manifest,indent=2)+'\n')
  print(f"round {round_index+1}/12 {variant}: status {result.returncode}, {entry['wall_seconds']:.2f}s",flush=True)
  if result.returncode: raise SystemExit(result.returncode)
