# Prepared single-inference benchmark

Per-run case medians of 21 >=2ms blocks; paired revision ratios across 12 order-balanced rounds; geometric mean ratio and seeded 20000-resample percentile 95% interval over rounds. Values below 1 are faster. Intervals describe this host and run protocol, not other machines.

All 36 fixture/output bit signatures match across three revisions and twelve rounds; 27216 raw timing blocks.

| Case | Baseline ns | Intermediate ns | Candidate ns | Candidate / baseline (95% CI) | Candidate / intermediate (95% CI) |
|---|---:|---:|---:|---:|---:|
| f32_linear_dense_100x50x25x10 | 1792.81 | 1787.74 | 1450.79 | 0.8124 [0.8019, 0.8216] | 0.8161 [0.8016, 0.8301] |
| f32_linear_dense_10x1 | 13.38 | 12.80 | 12.79 | 1.0031 [0.9462, 1.1128] | 0.9966 [0.8633, 1.1431] |
| f32_linear_dense_10x4x1 | 36.43 | 38.18 | 34.69 | 0.9984 [0.9436, 1.1057] | 0.9248 [0.8154, 1.0587] |
| f32_linear_dense_33x17x5 | 219.34 | 223.21 | 267.47 | 1.2276 [1.2044, 1.2576] | 1.1691 [1.1024, 1.2161] |
| f32_linear_dense_5x7x3 | 56.86 | 54.45 | 54.97 | 1.0142 [0.9544, 1.1319] | 1.0077 [0.9933, 1.0219] |
| f32_linear_dense_784x128x64x10 | 39222.21 | 38743.16 | 15701.83 | 0.4018 [0.3988, 0.4046] | 0.4040 [0.4006, 0.4070] |
| f32_linear_mixed_33x17x5 | 219.17 | 227.02 | 226.86 | 1.0361 [1.0244, 1.0466] | 0.9932 [0.9781, 1.0066] |
| f32_linear_reordered_33x17x5 | 244.26 | 264.68 | 249.99 | 1.0239 [1.0137, 1.0338] | 0.9235 [0.8737, 0.9586] |
| f32_linear_sparse_33x17x5 | 196.55 | 211.25 | 198.77 | 1.0164 [1.0094, 1.0240] | 0.9416 [0.9289, 0.9544] |
| f32_sigmoid_dense_100x50x25x10 | 2754.88 | 2770.63 | 1904.27 | 0.6926 [0.6860, 0.6994] | 0.6891 [0.6815, 0.6957] |
| f32_sigmoid_dense_10x1 | 19.68 | 18.49 | 18.63 | 0.9488 [0.9335, 0.9623] | 1.0095 [0.9972, 1.0215] |
| f32_sigmoid_dense_10x4x1 | 55.18 | 53.41 | 53.27 | 0.9714 [0.9606, 0.9821] | 0.9992 [0.9888, 1.0101] |
| f32_sigmoid_dense_33x17x5 | 345.74 | 325.65 | 348.78 | 1.0101 [1.0054, 1.0164] | 1.0710 [1.0631, 1.0780] |
| f32_sigmoid_dense_5x7x3 | 86.88 | 84.59 | 86.56 | 0.9939 [0.9875, 1.0004] | 1.0151 [1.0049, 1.0244] |
| f32_sigmoid_dense_784x128x64x10 | 42757.86 | 42518.48 | 16733.97 | 0.3932 [0.3901, 0.3965] | 0.3945 [0.3907, 0.3979] |
| f32_sigmoid_mixed_33x17x5 | 334.06 | 340.18 | 345.29 | 1.0323 [1.0227, 1.0403] | 1.0003 [0.9683, 1.0228] |
| f32_sigmoid_reordered_33x17x5 | 431.00 | 437.10 | 443.75 | 1.0315 [1.0236, 1.0404] | 1.0080 [0.9814, 1.0255] |
| f32_sigmoid_sparse_33x17x5 | 334.68 | 343.09 | 327.66 | 0.9824 [0.9727, 0.9931] | 0.9515 [0.9285, 0.9696] |
| f64_linear_dense_100x50x25x10 | 1779.77 | 1713.76 | 1690.55 | 0.9398 [0.8635, 1.0160] | 0.9804 [0.9023, 1.0569] |
| f64_linear_dense_10x1 | 13.63 | 12.70 | 12.51 | 0.8909 [0.8358, 0.9236] | 0.9867 [0.9829, 0.9905] |
| f64_linear_dense_10x4x1 | 37.86 | 36.87 | 33.81 | 0.8711 [0.8380, 0.8983] | 0.9155 [0.9095, 0.9208] |
| f64_linear_dense_33x17x5 | 221.04 | 241.96 | 268.41 | 1.1653 [1.0705, 1.2303] | 1.1103 [1.0969, 1.1218] |
| f64_linear_dense_5x7x3 | 55.31 | 54.64 | 52.96 | 1.0052 [0.9473, 1.1218] | 1.0213 [0.9623, 1.1397] |
| f64_linear_dense_784x128x64x10 | 39382.40 | 38871.15 | 23355.18 | 0.5894 [0.5766, 0.5990] | 0.6014 [0.5952, 0.6080] |
| f64_linear_mixed_33x17x5 | 269.89 | 240.93 | 268.27 | 0.9684 [0.8918, 1.0169] | 1.1238 [1.1071, 1.1421] |
| f64_linear_reordered_33x17x5 | 342.85 | 252.19 | 361.05 | 1.0477 [1.0345, 1.0602] | 1.4308 [1.4138, 1.4471] |
| f64_linear_sparse_33x17x5 | 256.46 | 200.50 | 266.73 | 1.0328 [1.0195, 1.0454] | 1.2592 [1.1315, 1.3390] |
| f64_sigmoid_dense_100x50x25x10 | 2928.69 | 2889.60 | 2190.00 | 0.7471 [0.7394, 0.7543] | 0.7565 [0.7457, 0.7642] |
| f64_sigmoid_dense_10x1 | 21.39 | 19.95 | 19.78 | 0.8601 [0.7473, 0.9286] | 0.9905 [0.9812, 0.9996] |
| f64_sigmoid_dense_10x4x1 | 66.63 | 58.66 | 61.06 | 0.9141 [0.9060, 0.9231] | 1.0408 [1.0322, 1.0490] |
| f64_sigmoid_dense_33x17x5 | 373.20 | 388.81 | 364.25 | 0.9707 [0.9590, 0.9811] | 0.9384 [0.9298, 0.9472] |
| f64_sigmoid_dense_5x7x3 | 101.12 | 97.13 | 98.28 | 0.9689 [0.9489, 0.9886] | 1.0147 [0.9986, 1.0306] |
| f64_sigmoid_dense_784x128x64x10 | 43001.82 | 43101.90 | 24362.15 | 0.5733 [0.5634, 0.5863] | 0.5742 [0.5632, 0.5905] |
| f64_sigmoid_mixed_33x17x5 | 384.37 | 380.59 | 393.34 | 1.0227 [1.0014, 1.0442] | 1.0402 [1.0287, 1.0545] |
| f64_sigmoid_reordered_33x17x5 | 494.58 | 461.63 | 509.38 | 1.0117 [0.9824, 1.0311] | 1.0689 [1.0042, 1.1069] |
| f64_sigmoid_sparse_33x17x5 | 383.62 | 348.72 | 381.32 | 0.9976 [0.9694, 1.0296] | 1.0993 [1.0725, 1.1308] |

## Group geometric means

| Comparison | Group | Cases | Ratio | 95% CI |
|---|---|---:|---:|---:|
| intermediate/baseline | all | 36 | 0.9716 | [0.9594, 0.9831] |
| intermediate/baseline | dense | 24 | 0.9786 | [0.9640, 0.9920] |
| intermediate/baseline | controls | 12 | 0.9576 | [0.9416, 0.9735] |
| intermediate/baseline | tiny | 12 | 0.9587 | [0.9323, 0.9830] |
| intermediate/baseline | large | 12 | 0.9990 | [0.9872, 1.0099] |
| candidate/baseline | all | 36 | 0.8970 | [0.8868, 0.9063] |
| candidate/baseline | dense | 24 | 0.8425 | [0.8295, 0.8547] |
| candidate/baseline | controls | 12 | 1.0167 | [1.0059, 1.0264] |
| candidate/baseline | tiny | 12 | 0.9518 | [0.9227, 0.9844] |
| candidate/baseline | large | 12 | 0.7457 | [0.7353, 0.7547] |
| candidate/intermediate | all | 36 | 0.9232 | [0.9105, 0.9357] |
| candidate/intermediate | dense | 24 | 0.8609 | [0.8476, 0.8738] |
| candidate/intermediate | controls | 12 | 1.0617 | [1.0468, 1.0763] |
| candidate/intermediate | tiny | 12 | 0.9929 | [0.9686, 1.0178] |
| candidate/intermediate | large | 12 | 0.7465 | [0.7393, 0.7541] |

## Regressions requiring review

- candidate/baseline, f32_linear_dense_10x1: 0.31% slower; 95% CI [0.9462, 1.1128]. Interval includes parity.
- candidate/baseline, f32_linear_dense_33x17x5: 22.76% slower; 95% CI [1.2044, 1.2576]. Interval excludes parity.
- candidate/baseline, f32_linear_dense_5x7x3: 1.42% slower; 95% CI [0.9544, 1.1319]. Interval includes parity.
- candidate/baseline, f32_linear_mixed_33x17x5: 3.61% slower; 95% CI [1.0244, 1.0466]. Interval excludes parity.
- candidate/baseline, f32_linear_reordered_33x17x5: 2.39% slower; 95% CI [1.0137, 1.0338]. Interval excludes parity.
- candidate/baseline, f32_linear_sparse_33x17x5: 1.64% slower; 95% CI [1.0094, 1.0240]. Interval excludes parity.
- candidate/baseline, f32_sigmoid_dense_33x17x5: 1.01% slower; 95% CI [1.0054, 1.0164]. Interval excludes parity.
- candidate/baseline, f32_sigmoid_mixed_33x17x5: 3.23% slower; 95% CI [1.0227, 1.0403]. Interval excludes parity.
- candidate/baseline, f32_sigmoid_reordered_33x17x5: 3.15% slower; 95% CI [1.0236, 1.0404]. Interval excludes parity.
- candidate/baseline, f64_linear_dense_33x17x5: 16.53% slower; 95% CI [1.0705, 1.2303]. Interval excludes parity.
- candidate/baseline, f64_linear_dense_5x7x3: 0.52% slower; 95% CI [0.9473, 1.1218]. Interval includes parity.
- candidate/baseline, f64_linear_reordered_33x17x5: 4.77% slower; 95% CI [1.0345, 1.0602]. Interval excludes parity.
- candidate/baseline, f64_linear_sparse_33x17x5: 3.28% slower; 95% CI [1.0195, 1.0454]. Interval excludes parity.
- candidate/baseline, f64_sigmoid_mixed_33x17x5: 2.27% slower; 95% CI [1.0014, 1.0442]. Interval excludes parity.
- candidate/baseline, f64_sigmoid_reordered_33x17x5: 1.17% slower; 95% CI [0.9824, 1.0311]. Interval includes parity.
- candidate/intermediate, f32_linear_dense_33x17x5: 16.91% slower; 95% CI [1.1024, 1.2161]. Interval excludes parity.
- candidate/intermediate, f32_linear_dense_5x7x3: 0.77% slower; 95% CI [0.9933, 1.0219]. Interval includes parity.
- candidate/intermediate, f32_sigmoid_dense_10x1: 0.95% slower; 95% CI [0.9972, 1.0215]. Interval includes parity.
- candidate/intermediate, f32_sigmoid_dense_33x17x5: 7.10% slower; 95% CI [1.0631, 1.0780]. Interval excludes parity.
- candidate/intermediate, f32_sigmoid_dense_5x7x3: 1.51% slower; 95% CI [1.0049, 1.0244]. Interval excludes parity.
- candidate/intermediate, f32_sigmoid_mixed_33x17x5: 0.03% slower; 95% CI [0.9683, 1.0228]. Interval includes parity.
- candidate/intermediate, f32_sigmoid_reordered_33x17x5: 0.80% slower; 95% CI [0.9814, 1.0255]. Interval includes parity.
- candidate/intermediate, f64_linear_dense_33x17x5: 11.03% slower; 95% CI [1.0969, 1.1218]. Interval excludes parity.
- candidate/intermediate, f64_linear_dense_5x7x3: 2.13% slower; 95% CI [0.9623, 1.1397]. Interval includes parity.
- candidate/intermediate, f64_linear_mixed_33x17x5: 12.38% slower; 95% CI [1.1071, 1.1421]. Interval excludes parity.
- candidate/intermediate, f64_linear_reordered_33x17x5: 43.08% slower; 95% CI [1.4138, 1.4471]. Interval excludes parity.
- candidate/intermediate, f64_linear_sparse_33x17x5: 25.92% slower; 95% CI [1.1315, 1.3390]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_dense_10x4x1: 4.08% slower; 95% CI [1.0322, 1.0490]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_dense_5x7x3: 1.47% slower; 95% CI [0.9986, 1.0306]. Interval includes parity.
- candidate/intermediate, f64_sigmoid_mixed_33x17x5: 4.02% slower; 95% CI [1.0287, 1.0545]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_reordered_33x17x5: 6.89% slower; 95% CI [1.0042, 1.1069]. Interval excludes parity.
- candidate/intermediate, f64_sigmoid_sparse_33x17x5: 9.93% slower; 95% CI [1.0725, 1.1308]. Interval excludes parity.
