from pathlib import Path
import csv,hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent

def stats():
    return {int(line.split()[0][3:]):list(map(int,line.split()[1:])) for line in Path('/proc/stat').read_text().splitlines() if line.split()[0].startswith('cpu') and line.split()[0][3:].isdigit()}

def choose_cpu():
    allowed=sorted(os.sched_getaffinity(0));before=stats();start=time.monotonic();time.sleep(2);after=stats();pairs={};util={}
    for cpu in allowed:
        delta=[r-l for l,r in zip(before[cpu],after[cpu])];total=sum(delta[:8]);busy=100*(total-delta[3]-delta[4])/total
        util[cpu]={'ticks':delta,'busy_percent':busy}
        p=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology');key=(int((p/'physical_package_id').read_text()),int((p/'core_id').read_text()))
        pairs.setdefault(key,[]).append(cpu)
    rows=[{'package':key[0],'core':key[1],'cpus':value,'busy_percent':[util[cpu]['busy_percent'] for cpu in value],'max_busy_percent':max(util[cpu]['busy_percent'] for cpu in value),'sum_busy_percent':sum(util[cpu]['busy_percent'] for cpu in value)} for key,value in pairs.items() if key[1]!=0]
    rows.sort(key=lambda row:(row['max_busy_percent'],row['sum_busy_percent'],row['core']!=11,min(row['cpus'])))
    report={'rule':'2secondprobe;excludephysicalcore0;minimizemaxsiblingbusy%,then summedbusy%;tieprefercore11thenlowerlogicalCPU;no rejectionthreshold','elapsed_seconds':time.monotonic()-start,'allowed':allowed,'per_cpu':util,'pairs':rows,'selected':rows[0],'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'loadavg':Path('/proc/loadavg').read_text().strip()}
    (ROOT/'selection.json').write_text(json.dumps(report,indent=2)+'\n')
    return min(rows[0]['cpus']),rows[0]

def main():
    metadata=json.loads((ROOT/'metadata.json').read_text())
    for name,path in [('baseline','/home/ruvultra/projects/ruv-FANN-training-baseline'),('candidate','/home/ruvultra/projects/ruv-FANN-rust-combined')]:
        assert not subprocess.check_output(['git','-C',path,'status','--porcelain'],text=True)
        assert hashlib.sha256((ROOT/name/'fann-dense-training-benchmark').read_bytes()).hexdigest()==metadata['builds'][name]['binary_sha256']
    cpu,pair=choose_cpu()
    metadata['timing_cpu']=cpu;metadata['timing_cpu_core']=pair['core'];metadata['timing_cpu_siblings']=pair['cpus']
    metadata['timing']={'outer_pairs':12,'inner_measurements_per_case':21,'inner_warmup_blocks':7,'order':'ABeven/BAodd','cpu':cpu,'pair':pair,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'cpu_stats_before':stats(),'loadavg_before':Path('/proc/loadavg').read_text().strip(),'pressure_before':Path('/proc/pressure/cpu').read_text()}
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print('SELECTED',json.dumps(pair),flush=True)
    events=[]
    for round_index in range(12):
        for name in (('baseline','candidate') if round_index%2==0 else ('candidate','baseline')):
            stem=f'run-{round_index:02d}-{name}';command=['taskset','-c',str(cpu),str(ROOT/name/'fann-dense-training-benchmark')];started=time.monotonic()
            with (ROOT/(stem+'.csv')).open('w') as output,(ROOT/(stem+'.stderr')).open('w') as errors:
                proc=subprocess.Popen(command,stdout=output,stderr=errors)
                affinity=[]
                for _ in range(100):
                    affinity=sorted(os.sched_getaffinity(proc.pid))
                    if affinity==[cpu]:break
                    time.sleep(0.001)
                assert affinity==[cpu],(stem,affinity)
                result=proc.wait()
            assert result==0,(stem,result)
            values=list(csv.DictReader((ROOT/(stem+'.csv')).open()))
            assert len(values)==252,(stem,len(values))
            cases={(row['precision'],row['shape'],row['topology']) for row in values}
            assert len(cases)==12,(stem,cases)
            assert all(sum((row['precision'],row['shape'],row['topology'])==case for row in values)==21 for case in cases)
            event={'round':round_index,'variant':name,'command':command,'observed_affinity':affinity,'elapsed_seconds':time.monotonic()-started,'raw_sha256':hashlib.sha256((ROOT/(stem+'.csv')).read_bytes()).hexdigest(),'loadavg_after':Path('/proc/loadavg').read_text().strip()}
            events.append(event)
        (ROOT/'timing-events.json').write_text(json.dumps(events,indent=2)+'\n')
        print('PAIR',round_index,'COMPLETE',flush=True)
    after=stats()
    metadata['timing'].update(finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),cpu_stats_after=after,loadavg_after=Path('/proc/loadavg').read_text().strip(),pressure_after=Path('/proc/pressure/cpu').read_text(),raw_rows=12*2*252)
    metadata['timing']['cpu_utilization']={}
    for cpu_id in pair['cpus']:
        before=metadata['timing']['cpu_stats_before'][str(cpu_id)] if str(cpu_id) in metadata['timing']['cpu_stats_before'] else metadata['timing']['cpu_stats_before'][cpu_id]
        delta=[r-l for l,r in zip(before,after[cpu_id])];total=sum(delta[:8])
        metadata['timing']['cpu_utilization'][cpu_id]={'ticks':delta,'busy_percent':100*(total-delta[3]-delta[4])/total}
    metadata['timing']['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (ROOT/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')

if __name__=='__main__':main()
